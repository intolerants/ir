#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "ufrn_al5d.h"



//   L1 = 2cm
 //   L2 = 14,5cm
 //   L3 = 18,5cm
 //   L4 = 7,0cm


double o1, o2, o3, o4;
int pbase, pombro, pcotovelo, ppunho, pgarra;
float L1 = 7.3 , L2= 14.6 , L3= 19, L4=7.2;
int teste;
int serial_fd;
char *comando;


//Posicao inicial para todos os servos
#define HOME_POS "#0P1500#1P1500#2P1500#3P1500#4P1500T10000"




int inversa (double x, double y, double z)
{
    double a,b,c,d;

    o1= atan2(y,x);
    b= (pow(x,2) + pow(y,2) +pow((z - L1 - L4),2) -pow(L3,2) -pow(L2,2))/(2*L3*L2);
    if (b>-1 && b<1)
    {
        o3= acos(b);
        c=((z - L1 - L4)*(L3 + L2*cos(o3)) + sin(o3)*L2*sqrt(pow(x,2) + pow(y,2)))/(pow(L3,2) + 2*L3*L2*cos(o3) + pow(L2,2));
        d=(-(z - L1 - L4)*L2*sin(o3) + (L3 + L2*cos(o3))*sqrt(pow(x,2) + pow(y,2)))/(pow(L3,2) + 2*L3*L2*cos(o3) + pow(L2,2));
        if(c>-1 && c<1)
        {
             a=atan2(c,d);
             o2= a - o3;
             o4= (M_PI_2) -o2 -o3;
             //Transformação de rad para grau:
             o1= o1*180/(M_PI);
             o2= o2*180/(M_PI);
             o3= o3*180/(M_PI);
             o4= o4*180/(M_PI);
             pbase=(-800*o1/90)+ 620;
             pombro=(9.01*o2/90)+ 635.3;
		     pcotovelo=(-8.72*o3)+893.3;
             ppunho=(9.9479*o4+1471.1);

//(-8.814*theta + 1558.6);  break;
//(9.01*theta + 635.3); break;
//(-8.72*theta + 893.3); break;
//(9.9479*theta + 1471.1); break;
//(theta/0.09 + 500); break;


             return 0;
        }
        else
        {
            return -1;
        }

    }
    else
    {
	
        return -1;

}

}


void REPOUSO (void){


    pbase=620;
    pombro=2200;
    pcotovelo=1000;
    ppunho=1450;


    sprintf(comando,"#%dP%d",BAS_SERVO,trava(BAS_SERVO,pbase));
    enviar_comando(comando,serial_fd);
    memset(comando, 0, BUFSIZE);


    sprintf(comando,"#%dP%d",SHL_SERVO,pombro);
    enviar_comando(comando,serial_fd);
    memset(comando, 0, BUFSIZE);


    sprintf(comando,"#%dP%d",ELB_SERVO,trava(ELB_SERVO,pcotovelo));
    enviar_comando(comando,serial_fd);
    memset(comando, 0, BUFSIZE);


    sprintf(comando,"#%dP%d",WRI_SERVO,trava(WRI_SERVO,ppunho));
    enviar_comando(comando,serial_fd);
    memset(comando, 0, BUFSIZE);

}

void PEGA (void){
    pgarra=2400;
    sprintf(comando,"#%dP%d",GRI_SERVO,trava(GRI_SERVO,pgarra));
    enviar_comando(comando,serial_fd);
    memset(comando, 0, BUFSIZE);

}

void COLOCA (void){
    pgarra=1500;
    sprintf(comando,"#%dP%d",GRI_SERVO,trava(GRI_SERVO,pgarra));
    enviar_comando(comando,serial_fd);
    memset(comando, 0, BUFSIZE);

}


void MOVE (void){


    double x,y,z;

    printf("Digite x: ");
    scanf("%lf",&x);

    printf("Digite y: ");
    scanf("%lf",&y);

    printf("Digite z: ");
    scanf("%lf",&z);

    teste=inversa(x, y, z);
    if (teste==0)
    {



                //Execução do comando para o braço robótico:
                memset(comando, 0, BUFSIZE);
                sprintf(comando,"#%dP%d",BAS_SERVO,trava(BAS_SERVO,pbase));
                enviar_comando(comando,serial_fd);

                memset(comando, 0, BUFSIZE);
                sprintf(comando,"#%dP%d",SHL_SERVO,pombro);
                enviar_comando(comando,serial_fd);

                memset(comando, 0, BUFSIZE);
                sprintf(comando,"#%dP%d",ELB_SERVO,trava(ELB_SERVO,pcotovelo));
                enviar_comando(comando,serial_fd);

                memset(comando, 0, BUFSIZE);
                sprintf(comando,"#%dP%d",WRI_SERVO,trava(WRI_SERVO,ppunho));
                enviar_comando(comando,serial_fd);


                }
    

    else
    {
        printf("\n erro: valores x,y,z fora da area de trabalho \n ");
    }

}


void ESCOLHE (void)
{
    char aux;
    printf("  P(PEGAR) C(COLOCA) R~(REPOUSO) ou M(MOVE)\n");
    scanf("%c",&aux);

    serial_fd = abrir_porta();

        if(serial_fd == -1)
        {
            printf("Erro abrindo a porta serial /dev/ttyS0\nAbortando o programa...");
            return -1;
        }
        else
        {
            printf("Porta serial /dev/ttyS0 aberta com sucesso\n");

            if(configurar_porta(serial_fd) == -1)
            {
                printf("Erro inicializando a porta\n");
                close(serial_fd);
                return -1;
            }

            comando = (char*) malloc(sizeof(char)*BUFSIZE);


            if(aux=='M'){
              MOVE();
             }
            else
            {
               if(aux=='R'){
               REPOUSO();
               }
               else
               {
                   if(aux=='C')
                   {
                      COLOCA();
                   }
                   else
                   {
                        if(aux=='P')
                       {

                           PEGA();
                       }
                    }
                }


              }

      }
}






int main()
{

    ufrn_header();

     int i=1;

    while(i!=0)
    {

        ESCOLHE();
        printf("\n para continuar digite 1, para sair digite 0: \n");
        scanf("%d",&i);
        getchar();
    }
    return 0;
}
